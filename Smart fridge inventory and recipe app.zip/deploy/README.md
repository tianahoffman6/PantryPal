# PantryPal

Smart fridge inventory & recipe app for Tiana & Baltej.

Built with 250 recipes, meal planner, barcode scanner, expiry notifications, and grocery export.

## Deployment

Hosted on GitHub Pages: https://tianahoffman6.github.io/PantryPal
